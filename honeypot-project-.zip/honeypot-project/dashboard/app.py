import json
import streamlit as st
from collections import Counter
from datetime import datetime

st.set_page_config(layout="wide")
st.title("SOC Honeypot Attack Analytics Dashboard")

attack_data_file = "/home/kartik/honeypot-project/logs/attack_data.json"
cowrie_log_file = "/home/kartik/honeypot-project/logs/cowrie.json"

# Load processed attack data
with open(attack_data_file) as f:
    attack_data = json.load(f)

# Load raw cowrie logs
with open(cowrie_log_file) as f:
    raw_logs = [json.loads(line) for line in f]

# ---------------- Threat Levels ----------------
st.subheader("Threat Level Distribution")
threat_levels = Counter(d["threat_level"] for d in attack_data)
st.bar_chart(threat_levels)

# ---------------- Attacks by Hour ----------------
st.subheader("Attacks by Hour")
hours = []
for e in raw_logs:
    ts = e.get("timestamp")
    if ts:
        hour = datetime.fromisoformat(ts.replace("Z","")).hour
        hours.append(hour)

st.line_chart(Counter(hours))

# ---------------- Password Analysis ----------------
st.subheader("Most Common Passwords")
passwords = [e.get("password") for e in raw_logs if e.get("password")]
st.write(Counter(passwords).most_common(5))

# ---------------- Command Analysis ----------------
st.subheader("Most Common Commands")
commands = [e.get("input") for e in raw_logs if e.get("eventid") == "cowrie.command.input"]
st.write(Counter(commands).most_common(5))

# ---------------- Command Risk Summary ----------------
st.subheader("Command Risk Classification")

high_risk = ["wget", "curl", "rm", "chmod", "nc"]
medium_risk = ["uname", "ip", "ifconfig"]
low_risk = ["ls", "pwd", "whoami"]

risk_count = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}

for e in raw_logs:
    if e.get("eventid") == "cowrie.command.input":
        cmd = e.get("input", "")
        if any(x in cmd for x in high_risk):
            risk_count["HIGH"] += 1
        elif any(x in cmd for x in medium_risk):
            risk_count["MEDIUM"] += 1
        elif any(x in cmd for x in low_risk):
            risk_count["LOW"] += 1

st.bar_chart(risk_count)
