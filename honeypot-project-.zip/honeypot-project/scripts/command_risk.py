import json
from collections import Counter

log_file = "/home/kartik/honeypot-project/logs/cowrie.json"

low_risk = ["ls", "pwd", "whoami"]
medium_risk = ["uname", "ifconfig", "ip"]
high_risk = ["wget", "curl", "chmod", "rm", "nc", "scp"]

risk_summary = Counter()

with open(log_file) as f:
    for line in f:
        event = json.loads(line)

        if event.get("eventid") == "cowrie.command.input":
            cmd = event.get("input", "")

            if any(c in cmd for c in high_risk):
                risk = "HIGH"
            elif any(c in cmd for c in medium_risk):
                risk = "MEDIUM"
            elif any(c in cmd for c in low_risk):
                risk = "LOW"
            else:
                risk = "UNKNOWN"

            risk_summary[risk] += 1
            print("Command:", cmd, "| Risk:", risk)

print("\nCommand Risk Summary:")
for k, v in risk_summary.items():
    print(k, ":", v)
