import json

input_log = "/home/kartik/cowrie/var/log/cowrie/cowrie.json"
output_file = "/home/kartik/honeypot-project/logs/attack_data.json"

results = []

dangerous_commands = ["wget", "curl", "chmod", "rm", "nc"]

def calculate_score(event):
    score = 0
    event_id = event.get("eventid", "")

    if "login.failed" in event_id:
        score += 2
    if "login.success" in event_id:
        score += 3
    if "command.input" in event_id:
        score += 2
        command = event.get("input", "")
        for d in dangerous_commands:
            if d in command:
                score += 5
    return score

with open(input_log) as f:
    for line in f:
        event = json.loads(line)
        ip = event.get("src_ip")

        score = calculate_score(event)

        if score >= 10:
            level = "HIGH"
        elif score >= 5:
            level = "MEDIUM"
        else:
            level = "LOW"

        results.append({
            "ip": ip,
            "event": event.get("eventid"),
            "score": score,
            "threat_level": level
        })

with open(output_file, "w") as out:
    json.dump(results, out, indent=4)

print("Attack data saved to attack_data.json")
