import json
import requests

log_file = "/home/kartik/cowrie/var/log/cowrie/cowrie.json"

def get_ip_info(ip):
    url = f"http://ip-api.com/json/{ip}"
    response = requests.get(url)
    data = response.json()
    return data

with open(log_file) as f:
    for line in f:
        event = json.loads(line)
        ip = "8.8.8.8"

        if ip:
            info = get_ip_info(ip)
            print("IP:", ip)
            print("Country:", info.get("country"))
            print("ISP:", info.get("isp"))
            print("ASN:", info.get("as"))
            print("------")
            break

