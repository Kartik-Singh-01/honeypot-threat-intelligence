import json

log_file = "/home/kartik/cowrie/var/log/cowrie/cowrie.json"

dangerous_commands = ["wget", "curl", "chmod", "rm", "nc"]

def calculate_score(event):
    score = 0
    event_id = event.get("eventid", "")

    if "login.failed" in event_id:
        score += 2
    if "login.success" in event_id:
        score += 3
    if "command.input" in event_id:
        score += 2

        command = event.get("input", "")
        for d in dangerous_commands:
            if d in command:
                score += 5

    return score

with open(log_file) as f:
    for line in f:
        event = json.loads(line)
        ip = event.get("src_ip")

        score = calculate_score(event)

        if score >= 10:
            level = "HIGH"
        elif score >= 5:
            level = "MEDIUM"
        else:
            level = "LOW"

        print("IP:", ip, "| Score:", score, "| Threat:", level)
