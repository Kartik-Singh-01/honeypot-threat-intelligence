import json
from collections import Counter
from datetime import datetime

log_file = "/home/kartik/cowrie/var/log/cowrie/cowrie.json"

hours = []
passwords = []
commands = []

with open(log_file) as f:
    for line in f:
        event = json.loads(line)

        # Time-based analysis
        ts = event.get("timestamp")
        if ts:
            hour = datetime.fromisoformat(ts.replace("Z","")).hour
            hours.append(hour)

        # Password analysis
        if "password" in event:
            passwords.append(event.get("password"))

        # Command analysis
        if event.get("eventid") == "cowrie.command.input":
            commands.append(event.get("input"))

print("Most common attack hours:", Counter(hours).most_common(5))
print("Most common passwords:", Counter(passwords).most_common(5))
print("Most common commands:", Counter(commands).most_common(5))
